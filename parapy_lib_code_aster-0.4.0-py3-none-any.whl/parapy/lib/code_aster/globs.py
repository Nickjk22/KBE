# -*- coding: utf-8 -*-
#
# Copyright (C) 2016-2023 ParaPy Holding B.V.
#
# This file is subject to the terms and conditions defined in
# the license agreement that you have received with this source code
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
# PURPOSE.

import os
import sys


def is_frozen() -> bool:
    return hasattr(sys, "frozen")


def main_dir() -> str:
    encoding = sys.getfilesystemencoding()
    if is_frozen():
        return os.path.join(os.path.dirname(sys.executable), "parapy", "lib", "code_aster")
    return os.path.dirname(os.path.abspath(__file__))


PKG_DIR = main_dir()
TEMPLATE_DIR = os.path.join(PKG_DIR, "template")
EXPORT_TMPLT = os.path.join(TEMPLATE_DIR, "export.tmplt")
COMM_TMPLT = os.path.join(TEMPLATE_DIR, "comm.tmplt")

if __name__ == "__main__":
    print(PKG_DIR)
    print(TEMPLATE_DIR)
