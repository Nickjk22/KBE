# -*- coding: utf-8 -*-
#
# Copyright (C) 2016-2023 ParaPy Holding B.V.
#
# This file is subject to the terms and conditions defined in
# the license agreement that you have received with this source code
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
# PURPOSE.

from typing import Union

from parapy.lib.fem.base import Field, Primitive
from parapy.lib.fem.writer import WriterContext


class Command(Primitive):
    def to_str(self, context: WriterContext) -> str:
        field_instances = self.to_field_instances()
        command_name = self.type
        commands = ""
        for field_instance in field_instances:
            field, value = field_instance.field, field_instance.value
            if value is None:
                continue

            if not field.is_reference:
                arg = f"{field.name}={repr(value)},"
                commands += arg
                continue

            if field.is_sequence:
                lst = []
                for element in value:
                    if isinstance(element, Command):
                        uid = context.get_uid(element)
                        lst.append(self.create_uid(element.type, uid))
                    else:
                        lst.append(value)
                arg = f"{field.name}=({', '.join(lst)}),"
                commands += arg
                continue

            if isinstance(value, Command):
                uid = context.get_uid(value)
                value = self.create_uid(value.type, uid)
            arg = f"{field.name}={value},"
            commands += arg

        uid = context.get_uid(self)
        uid = self.create_uid(command_name, uid)
        return f"{uid}={command_name}({commands})"

    def create_uid(self, command_name: str, uid_postfix: int) -> str:
        command_name = command_name[:3]  # code aster limits uid to 8 chars
        return f"{command_name}{uid_postfix}"


class SequenceField(Field):
    def __init__(self, atomic_type: Union[str, float, int] = None):
        super().__init__(atomic_type, is_sequence=True, unpack_sequence=False)
