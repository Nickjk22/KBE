# -*- coding: utf-8 -*-
#
# Copyright (C) 2016-2023 ParaPy Holding B.V.
#
# This file is subject to the terms and conditions defined in
# the license agreement that you have received with this source code
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
# PURPOSE.

import os
from typing import Dict, List

from parapy.core import Attribute, Base, Input
from parapy.core.globs import ICN_DIR

__all__ = ["ResultsReaderBase"]

_RESULT_SEPARATOR = "------>"


class ResultsReaderBase(Base):
    __icon__ = os.path.join(ICN_DIR, "input.png")

    file_path = Input()

    @Attribute
    def parsed_results(self) -> List[List[str]]:
        return parse_results(self.file_path)

    @Attribute
    def results(self) -> Dict[str, List[List[str]]]:
        dct = {}
        for field in self.parsed_results:
            field_name = field[0].split()[-1]
            results = field[2:]
            dct[field_name] = results
        return dct

    def read(self) -> Dict[str, List[List[str]]]:
        return self.results


def parse_results(file_path: str) -> List[List[str]]:
    """Take a result file and return a list of lists with the results."""
    with open(file_path, "r") as reader:
        file_content = reader.read()

    # First section of the results file is some CodeAster info
    results = file_content.split(_RESULT_SEPARATOR)[1:]

    result_lst = []
    for result in results:
        result_lst.append(_parse_single_result(result))

    return result_lst


def _parse_single_result(result: str) -> List[str]:
    result_lines = result.split("\n")
    result_lst = []

    end_markers = ["======>", "--------"]
    for line in result_lines:
        if any(marker in line for marker in end_markers):
            break
        result_lst.append(line)

    # Lazy clean-up
    for result in reversed(result_lst):
        if result.isspace() or len(result) < 1:
            result_lst.remove(result)
        else:
            break

    return result_lst
