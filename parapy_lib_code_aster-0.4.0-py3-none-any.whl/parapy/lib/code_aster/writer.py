# -*- coding: utf-8 -*-
#
# Copyright (C) 2016-2023 ParaPy Holding B.V.
#
# This file is subject to the terms and conditions defined in
# the license agreement that you have received with this source code
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
# PURPOSE.

from dataclasses import dataclass
from typing import Literal, Optional, Sequence

from parapy.lib.code_aster.globs import TEMPLATE_DIR
from parapy.lib.fem.register import Register
from parapy.lib.fem.writer import WriterBase, WriterContext
from parapy.mesh.salome.grid import Grid


class CommandWriter(WriterBase):
    TEMPLATE_DIR = TEMPLATE_DIR
    DEFAULT_TEMPLATE_NAME = "comm.tmplt"

    def get_content(self) -> str:
        template_values = self._get_template_defauls()
        if self.template_values:
            template_values.update(self.template_values)
        template = self._get_jinja_template()

        register = Register()
        for prim in self.primitives:
            register.add(prim)

        writer_context = WriterContext(get_uid=register.get_uid)
        lines = []
        for prim in register._primitive_to_uid:
            prim = prim.to_str(writer_context)
            lines.append(prim)
        lines.append("")

        template_values["command_lines"] = lines
        return template.render(**template_values)


_SECTION_END = "FINSF\n%\n"


@dataclass
class MeshGroup:
    label: str
    header: Literal[
        "GROUP_NO",
        "GROUP_MA",
    ]
    element_ids: Sequence[int]
    element_type: Literal["node", "edge", "face"]
    element_type_to_prefix = {"node": "N", "edge": "E", "face": "m"}

    def to_str(self) -> str:
        data = f"{self.header}\n"
        data += self.label + "\n"
        prefix = self.element_type_to_prefix[self.element_type]
        for i, idx in enumerate(self.element_ids):
            data += f"{prefix}{idx: <10} "
            if i > 0 and i % 6 == 0:  # lines shall not exceed 80 characters
                data += "\n"
        data += "\n"
        data += _SECTION_END
        return data


class MeshWriter:
    def __init__(
        self, grid: Grid, groups: Sequence[MeshGroup], node_format: str = ">20.6E"
    ) -> None:
        self.grid = grid
        self.groups = groups
        self.node_format = node_format

    def _write_nodes(self) -> str:
        nf = self.node_format
        nodes = self.grid.nodes
        data = "COOR_3D\n"
        for n in nodes:
            data += f"N{n.mesh_id: <10} {n.x:{nf}} {n.y:{nf}} {n.z:{nf}}\n"

        data += _SECTION_END
        return data

    def _write_edges(self) -> str:
        edges = self.grid.edges
        data = "SEG2\n"
        for e in edges:
            data += f"E{e.mesh_id: <10} N{e.start.mesh_id: <10} N{e.end.mesh_id: <10}\n"

        data += _SECTION_END
        return data

    def _write_faces(self) -> str:
        faces = self.grid.faces
        tri_faces = filter(lambda f: len(f.nodes) == 3, faces)
        data = "TRIA3\n"
        for face in tri_faces:
            id1, id2, id3 = (node.mesh_id for node in face.nodes)
            data += f"m{face.mesh_id: <10} N{id1: <10} N{id2: <10} N{id3: <10}\n"
        data += _SECTION_END

        quad_faces = filter(lambda f: len(f.nodes) == 4, faces)
        data += "QUAD4\n"
        for face in quad_faces:
            id1, id2, id3, id4 = (node.mesh_id for node in face.nodes)
            data += f"m{face.mesh_id: <10} N{id1: <10} N{id2: <10} N{id3: <10} N{id4: <10}\n"
        data += _SECTION_END
        return data

    def write(self, pathname: Optional[str] = None):
        data = self._write_nodes()
        data += self._write_edges()
        data += self._write_faces()
        for group in self.groups:
            data += group.to_str()

        data += "FIN\n\n"
        with open(pathname, "w") as f:
            f.write(data)
        print(f"Written: {pathname}")
