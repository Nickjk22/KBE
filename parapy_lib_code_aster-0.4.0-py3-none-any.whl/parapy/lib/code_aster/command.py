# -*- coding: utf-8 -*-
#
# Copyright (C) 2016-2023 ParaPy Holding B.V.
#
# This file is subject to the terms and conditions defined in
# the license agreement that you have received with this source code
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
# PURPOSE.

from typing import Optional, Sequence, Tuple

from parapy.lib.fem.base import Identifier, Reference
from parapy.lib.code_aster.command_base import Command, SequenceField


class LIRE_MAILLAGE(Command):
    ID: Identifier
    UNITE: int
    FORMAT: Optional[str]


class _F(Command):
    ID: Identifier
    GROUP_MA: Optional[Sequence[str]] = SequenceField()
    MODELISATION: Optional[Sequence[str]] = SequenceField()
    PHENOMENE: Optional[str]
    GROUP_NO: Optional[Sequence[str]] = SequenceField()
    DX: Optional[int]
    DY: Optional[int]
    DZ: Optional[int]
    FX: Optional[int]
    FY: Optional[int]
    FZ: Optional[int]
    EPAIS: Optional[float]
    VECTEUR: Optional[Tuple[float, float, float]]
    RESI_RELA: Optional[float]
    CHARGE: Optional[Reference["AFFE_CHAR_MECA"]]
    NOM_CHAM: Optional[Sequence[str]] = SequenceField()
    RESULTAT: Optional[Reference["MECA_STATIQUE"]]
    E: Optional[float]
    RHO: Optional[float]
    NU: Optional[float]
    MATER: Optional[Sequence[Reference["DEFI_MATERIAU"]]] = SequenceField()
    LIAISON: Optional[str]


class AFFE_MODELE(Command):
    ID: Identifier
    AFFE: Sequence[Reference[_F]] = SequenceField()
    MAILLAGE: Reference[LIRE_MAILLAGE]


class AFFE_CARA_ELEM(Command):
    ID: Identifier
    MODELE: Reference[AFFE_MODELE]
    COQUE: Sequence[Reference[_F]] = SequenceField()


class DEFI_MATERIAU(Command):
    ID: Identifier
    ELAS: Reference[_F]
    MODELE: Reference[AFFE_MODELE]


class AFFE_CHAR_MECA(Command):
    ID: Identifier
    DDL_IMPO: Optional[Reference[_F]]
    FORCE_COQUE: Optional[Reference[_F]]
    FORCE_NODALE: Optional[Reference[_F]]
    FORCE_ARETE: Optional[Reference[_F]]
    MODELE: Reference[AFFE_MODELE]


class AFFE_MATERIAU(Command):
    ID: Identifier
    AFFE: Sequence[Reference[_F]] = SequenceField()
    MAILLAGE: Reference[LIRE_MAILLAGE]
    MODELE: Reference[AFFE_MODELE]


class MECA_STATIQUE(Command):
    ID: Identifier
    SOLVEUR: Reference[_F]
    CARA_ELEM: Reference[AFFE_CARA_ELEM]
    CHAM_MATER: Reference[AFFE_MATERIAU]
    EXCIT: Sequence[Reference[_F]] = SequenceField()
    MODELE: Reference[AFFE_MODELE]


class IMPR_RESU(Command):
    FORMAT: str
    RESU: Sequence[Reference[_F]] = SequenceField()
    UNITE: int
