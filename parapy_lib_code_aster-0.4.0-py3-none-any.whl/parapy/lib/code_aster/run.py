# -*- coding: utf-8 -*-
#
# Copyright (C) 2016-2023 ParaPy Holding B.V.
#
# This file is subject to the terms and conditions defined in
# the license agreement that you have received with this source code
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
# PURPOSE.

import os
import re
import shutil
import stat
import sys
import time
import warnings
from collections import namedtuple
from subprocess import PIPE, Popen
from typing import NamedTuple

from dotenv import find_dotenv, load_dotenv

from parapy.lib.code_aster.globs import EXPORT_TMPLT

__all__ = [
    "run_code_aster",
    "create_export_file",
    "delete_files",
    "generate_filepaths",
]


class CommFileVariableNameError(RuntimeError):
    pass


class FilePathError(ValueError):
    pass


def get_as_run_file(aster_bin: str) -> str:
    if sys.platform.startswith("win"):
        return os.path.join(aster_bin, "as_run.bat")
    elif sys.platform.startswith("linux"):
        return os.path.join(aster_bin, "as_run")
    else:
        raise NotImplementedError(
            f"Operation system {sys.platform} is not" f"supported."
        )


def create_export_file(
    target_path: str,
    mesh_path: str,
    comm_path: str,
    results_path: str,
    template_path: str = EXPORT_TMPLT,
    results_address: int = 8,
) -> None:
    """Copy and fill `.export`-file for code_aster.

    :param str template_path: path to template of export file
    :param str target_path: path to location export file should be written to
    :param str mesh_path: path to mesh file to use
    :param str comm_path: path to command file to use
    :param str results_path: path to results file that will be written
    """
    shutil.copy(template_path, target_path)

    with open(target_path, "a") as f:
        f.write(
            f"\n"
            f"F libr {mesh_path} D 20\n"
            f"\n"
            f"F libr {comm_path} D 1\n"
            f"\n"
            f"F libr {results_path} R  {results_address}\n"
        )
        print(f"Written: {target_path}")


def delete_files(paths) -> None:
    """Delete all files given in paths.

    If a file with read-only status is encountered file permission is
    changed to be able to remove file

    :param Iterable[str] paths: file paths to delete
    """
    for path in paths:
        if os.path.exists(path):
            try:
                os.remove(path)
            except PermissionError:
                os.chmod(path, stat.S_IWRITE)
                os.remove(path)


def generate_filepaths(target_directory: str, grid_format: str) -> NamedTuple:
    """Generate file paths for code_aster files in target_directory.

    :param str target_directory: directory to create files in
    :param str grid_format: `aster` or `med`
    :rtype: namedtuple
    """
    validate_file_path(target_directory)
    comm_file = os.path.join(target_directory, "case.comm")
    mesh_ext = "mail" if grid_format == "aster" else "med"
    mesh_file = os.path.join(target_directory, f"mesh.{mesh_ext}")
    export_file = os.path.join(target_directory, "case.export")
    results_file = os.path.join(target_directory, "results.txt")
    tuple_ = namedtuple(
        "file_paths", ["comm_file", "export_file", "mesh_file", "results_file"]
    )
    return tuple_(comm_file, export_file, mesh_file, results_file)


def run_code_aster(
    export_file: str, write_log: bool = True, log_file: str = None
) -> None:
    """Run Code_Aster using an export-file.

    :param str export_file: path to the export file defining case.comm to run.
    :param bool write_log: Flag to write code_aster log to file.
    :param str log_file: path to write logfile to, if not given use current
        working directory.
    """
    validate_file_path(export_file)

    dotenv_file = find_dotenv(usecwd=True)
    load_dotenv(dotenv_path=dotenv_file)
    aster_bin = os.environ.get("ASTER_BIN_PATH")
    if aster_bin is None:
        msg = (
            "No `.env` file present in the current working directory that specifies "
            "the path to a code_aster bin directory via the variable ASTER_BIN_PATH. Please create one first."
        )
        raise RuntimeError(msg)
    if not os.path.isdir(aster_bin):
        raise RuntimeError(
            "Got an invalid aster_bin path. Please ensure "
            "the right path is given in the `.env` file."
        )

    aster_run_file = get_as_run_file(aster_bin)
    args = [aster_run_file, export_file]

    start_t = time.perf_counter()
    aster_run = Popen(args, stdout=PIPE, stderr=PIPE)
    out, err = aster_run.communicate()  # start process and wait to it terminates
    elapsed_t = time.perf_counter() - start_t

    if write_log:
        write_log_file(out, log_file)

    if aster_run.returncode != 0:
        msg = find_error_message(out, log_file)
        raise RuntimeError(
            f"An error occurred during the code_aster "
            f"analysis. The error message is: \n {msg}"
        )

    else:
        print(f"Code Aster run finished successfully in {elapsed_t} seconds.")


def find_error_message(out, log_file: str) -> str:
    """Find code_aster error message in the output stream.

    :param bytes out: stdout stream of code_aster
    :param str log_file: file path to write logfile to
    :returns str: error message
    :raises RuntimeError: No error message found in `out`
    """
    pat = re.compile(b"\s*!{2,}")
    matches = list(re.finditer(pat, out))
    if len(matches) != 2:
        write_log_file(out, log_file)

        raise RuntimeError(
            "An error occurred during the code_aster "
            "analysis but the error cannot be retrieved "
            "from the log. Find the complete log in "
            "the working directory."
        )
    msg_start = matches[0].span()[0]
    msg_end = matches[1].span()[1]
    msg = out[msg_start:msg_end].decode(sys.stdout.encoding)
    return msg


def validate_variable_names(comm_path: str, action: str = "raise") -> None:
    """Check if any variable names in comm-file violate character limit."""
    pattern = r"([a-zA-Z0-9_]*)\s="
    with open(comm_path, "r") as f:
        string = f.read()

    names = list(re.findall(pattern, string))
    violators = []
    for name in names:
        if len(name) > 8:
            violators.append(name)

    if violators:
        msg = (
            "Found variable names that exceed the 8 character limit. "
            "Ensure variable names do not exceed this limit.\n"
            "Violators: {}".format(violators)
        )
        if action == "warn":
            warnings.warn(msg)
        else:
            raise CommFileVariableNameError(msg)


def validate_file_path(file_path: str) -> bool:
    """Check if file path contains spaces (not supported by code aster).

    :raises FilePathError:
    :rtype: bool
    """
    if " " in file_path:
        msg = (
            f"Code aster does not support file paths with spaces. "
            f"File path: {file_path} "
        )
        raise FilePathError(msg)
    return True


def write_log_file(out, log_file: str) -> None:
    path = log_file or "./aster_log.txt"
    with open(path, "wb") as f:
        f.write(out)
